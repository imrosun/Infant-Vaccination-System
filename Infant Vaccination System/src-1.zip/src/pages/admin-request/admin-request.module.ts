import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRequestPage } from './admin-request';

@NgModule({
  declarations: [
    // AdminRequestPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRequestPage),
  ],
})
export class AdminRequestPageModule {}
