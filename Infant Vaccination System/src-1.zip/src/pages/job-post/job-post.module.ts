import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobPostPage } from './job-post';

@NgModule({
  declarations: [
    // JobPostPage,
  ],
  imports: [
    IonicPageModule.forChild(JobPostPage),
  ],
})
export class JobPostPageModule {}
