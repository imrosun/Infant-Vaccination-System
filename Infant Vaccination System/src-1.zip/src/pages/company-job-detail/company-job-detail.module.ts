import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompanyJobDetailPage } from './company-job-detail';

@NgModule({
  declarations: [
    // CompanyJobDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(CompanyJobDetailPage),
  ],
})
export class CompanyJobDetailPageModule {}
