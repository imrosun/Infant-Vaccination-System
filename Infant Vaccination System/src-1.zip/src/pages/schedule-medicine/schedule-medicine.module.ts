import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScheduleMedicinePage } from './schedule-medicine';

@NgModule({
  declarations: [
    // ScheduleMedicinePage,
  ],
  imports: [
    IonicPageModule.forChild(ScheduleMedicinePage),
  ],
})
export class ScheduleMedicinePageModule {}
