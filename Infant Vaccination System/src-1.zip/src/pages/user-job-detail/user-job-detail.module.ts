import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UserJobDetailPage } from './user-job-detail';

@NgModule({
  declarations: [
    // UserJobDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(UserJobDetailPage),
  ],
})
export class UserJobDetailPageModule {}
