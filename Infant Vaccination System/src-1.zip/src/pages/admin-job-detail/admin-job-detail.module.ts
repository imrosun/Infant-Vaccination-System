import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminJobDetailPage } from './admin-job-detail';

@NgModule({
  declarations: [
    // AdminJobDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminJobDetailPage),
  ],
})
export class AdminJobDetailPageModule {}
