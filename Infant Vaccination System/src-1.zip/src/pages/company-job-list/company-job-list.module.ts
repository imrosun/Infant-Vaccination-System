import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompanyJobListPage } from './company-job-list';

@NgModule({
  declarations: [
    // CompanyJobListPage,
  ],
  imports: [
    IonicPageModule.forChild(CompanyJobListPage),
  ],
})
export class CompanyJobListPageModule {}
