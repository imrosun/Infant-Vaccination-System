import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompanyEditJobPage } from './company-edit-job';

@NgModule({
  declarations: [
    // CompanyEditJobPage,
  ],
  imports: [
    IonicPageModule.forChild(CompanyEditJobPage),
  ],
})
export class CompanyEditJobPageModule {}
